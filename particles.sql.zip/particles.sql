-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 12 2016 г., 09:50
-- Версия сервера: 5.5.50
-- Версия PHP: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `forsite`
--

-- --------------------------------------------------------

--
-- Структура таблицы `particles`
--

CREATE TABLE IF NOT EXISTS `particles` (
  `id` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `content0` longtext NOT NULL,
  `content1` longtext NOT NULL,
  `content2` longtext NOT NULL,
  `content3` longtext NOT NULL,
  `content4` longtext NOT NULL,
  `content5` longtext NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `particles`
--

INSERT INTO `particles` (`id`, `create_date`, `content0`, `content1`, `content2`, `content3`, `content4`, `content5`) VALUES
(1, '2016-12-12', 'HTML код', 'Скопіюйте цей код і вставте в себе у редактор', 'Скопіюйте цей код і вставте в себе у редактор:&lt;html&gt;&lt;head&gt;&lt;title&gt;Моя перша сторінка&lt;/title&gt;&lt;/head&gt;&lt;body&gt;Привіт світ! Це мій перший сайт&lt;/body&gt;&lt;/html&gt;Тепер потрібно зберегти зміни,для цього натисніть ctrl s або виберіть вручну у меню – File – Save', '20pt', '000000', '000000'),
(2, '2016-12-12', 'HTML урок1', 'синтаксис коментаря', 'Синтаксис коментаря: &lt;!-- Це коментар --&gt;Приклад застосування:&lt;html&gt;&lt;head&gt;&lt;title&gt;Коментарі&lt;/title&gt;&lt;/head&gt;&lt;body&gt;&lt;p&gt;Будь-який текст&lt;!-- А це коментар. Він не буде показаним на сторінці  --&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;Коментарі, розташовані всередині елемента TITLE трактуються як текст і будуть видні в заголовку вікна як текст. Інакше кажучи, тег &lt;!– –&gt; всередині TITLE не працюватиме.', '20pt', '993300', 'ffffff'),
(3, '2016-12-12', 'Абзаци в html ', 'Абзаци в html використовуються для зручного компонування тексту додаючи пропуски.', 'Абзаци в html використовуються для зручного компонування тексту додаючи пропуски.Абзац створює тег &lt;p&gt;Для зручності я писатиму лише частину коду(це записується у середині тегів body)', '32pt', '006600', '0000cc'),
(4, '2016-12-12', 'HTML код приклад', 'приклад коду', '&lt;html&gt;&lt;head&gt;&lt;link rel=&quot;stylesheet&quot; href=&quot;main_view_blocks.css&quot; type=&quot;text/css&quot;/&gt;&lt;script src=&quot;for_admin_btn.js&quot; language=&quot;javascript&quot;&gt;&lt;/script&gt;&lt;script src=&quot;ajax_framework2.js&quot; language=&quot;javascript&quot;&gt;&lt;/script&gt;&lt;/head&gt;&lt;body onload=&quot;fu_onload();&quot; class = &quot;bodystyle&quot;&gt;&lt;div class = &quot;header_div&quot; id = &quot;mainheaderdiv&quot;&gt;&lt;p style = &quot;text-align:center;&quot;&gt;Сайт зі статтями&lt;/p&gt;&lt;img src = &quot;cat.jpg&quot; width=&quot;144&quot; height=&quot;108&quot; style = &quot;right:5px; top:7px; position:absolute;&quot;/&gt;&lt;/div&gt;&lt;div class = &quot;left_div&quot; id = &quot;mainleftdiv&quot;&gt;&lt;form action=&quot;javascript:func_admin_btn()&quot; method=&quot;post&quot;&gt;&lt;input type=&quot;submit&quot; name=&quot;admin_btn&quot; value=&quot;Сторінка адміністратора&quot;/&gt;&lt;/form&gt;&lt;p&gt;Введіть пароль autovhid, щоб мати можливість додавати нові теми&lt;/p&gt;&lt;/div&gt;&lt;div class = &quot;center_left_div&quot; id = &quot;maincenterleftdiv&quot;&gt;&lt;form action=&quot;library_view.php&quot; method=&quot;post&quot; enctype=&quot;multipart/form-data&quot; class = &quot;unvisible&quot; id = &quot;f2&quot; name = &quot;f22&quot; style = &quot;right:5px; top:0px; position:absolute;&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;vrse18&quot; size=&quot;20&quot; maxlength=&quot;50&quot; id = &quot;inp18&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;vrse19&quot; size=&quot;20&quot; maxlength=&quot;50&quot; id = &quot;inp19&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;vrse20&quot; size=&quot;20&quot; maxlength=&quot;50&quot; id = &quot;inp20&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;vrse21&quot; size=&quot;20&quot; maxlength=&quot;50&quot; id = &quot;inp21&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;vrse22&quot; size=&quot;20&quot; maxlength=&quot;50&quot; id = &quot;inp22&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;vrse23&quot; size=&quot;20&quot; maxlength=&quot;50&quot; id = &quot;inp23&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;vrse24&quot; size=&quot;20&quot; maxlength=&quot;50&quot; id = &quot;inp24&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;vrse25&quot; size=&quot;20&quot; maxlength=&quot;50&quot; id = &quot;inp25&quot;&gt;&lt;input type=&quot;submit&quot; name=&quot;knpka2&quot; value=&quot;Видалити&quot; id = &quot;sbmtt&quot;&gt; &lt;/form&gt;&lt;div class = &quot;article_div&quot; style = &quot;align:center;&quot; id = &quot;articlediv&quot;&gt;&lt;p&gt;article_div&lt;/p&gt;&lt;/div&gt;&lt;/div&gt;&lt;div class = &quot;footer_div&quot; id = &quot;mainfooterdiv&quot;&gt;&lt;p&gt;footer&lt;/p&gt;&lt;/div&gt;&lt;/body&gt;&lt;/html&gt;', '20pt', '000000', '000000'),
(5, '2016-12-12', 'Чеширський кіт', 'У графстві Чешир, де народився Керрол, невідомий маляр над дверима таверн малював котів, що посміхалися', 'У графстві Чешир, де народився Керрол, невідомий маляр над дверима таверн малював котів, що посміхалися Здатність зникати Чеширський кіт перейняв у привида Конглтонского кота. Він був улюбленцем доглядачки абатства, але одного дня не повернувся додому. Через декілька днів господиня почула дряпання в двері, на порозі сидів її улюблений білий кіт, але через мить він розчинився у повітрі. Впродовж багатьох років привид кота бачило багато людей. Мабуть, автор був захоплений цією легендою і використав образ кота-привида для свого Чеширського кота.', '20pt', '0000cc', 'ffffff'),
(6, '2016-12-12', 'Пан Коцький', 'В одного чоловіка був кіт старий, що вже не здужав і мишей ловити.', 'В одного чоловіка був кіт старий, що вже не здужав і мишей ловити. От хазяїн його взяв та й вивіз у ліс, думає: «Нащо він мені здався, тільки дурно буду годувати,— нехай лучче в лісі ходить».', '20pt', '993300', '000000'),
(7, '2016-12-12', 'Коза Дереза', 'Були собі дід та баба. Поїхав дід на ярмарок та й купив собі козу.', 'Були собі дід та баба. Поїхав дід на ярмарок та й купив собі козу.Привіз її додому, а рано на другий день посилає дід старшого сина ту козу пасти. Пас, пас хлопець її аж до вечора та й став гнати додому. Тільки до воріт став доганяти, а дід став на воротях у червоних чоботях та й питається:— Кізонько моя мила, кізонько моя люба! Чи ти пила, чи ти їла?— Ні, дідусю, я й не пила, я й не їла: тільки бігла через місточок та вхопила кленовий листочок, тільки бігла через гребельку та вхопила водиці крапельку,— тільки пила, тільки й їла!', '28pt', 'ffffff', '006600'),
(8, '2016-12-12', 'Дід Бабай', 'Баба́й (баба́йка) — нічний дух, уявна істота, згадування якої використовують батьки, щоб залякати неслухняних дітей.', 'Баба́й (баба́йка) — нічний дух, уявна істота, згадування якої використовують батьки, щоб залякати неслухняних дітей. Бабай описується як «маленький дідусь з бородою і з торбинкою або великим мішком». Іноді Бабай не описується взагалі; в цьому випадку діти уявляють його самі.Зазвичай Бабай використовується, щоб неслухняні діти не вставали з ліжка після того, як їх уклали спати. В цьому випадку батьки говорять, що Бабай ховається під ліжком, і що він забере дитину, якщо та встане.', '20pt', '000000', '000000'),
(9, '2016-12-12', 'Дід Мороз', 'Дід Моро́з — казковий персонаж святкування Нового року спочатку в СРСР, згодом у пострадянських державах, який вручає дітям подарунки особисто або кладе під ялинку.', 'Дід Моро́з — казковий персонаж святкування Нового року спочатку в СРСР, згодом у пострадянських державах, який вручає дітям подарунки особисто або кладе під ялинку. Дід Мороз часто зображується в довгій синій або червоній шубі, підперезаній поясом, з довгою білою бородою, в хутряній шапці й валянках.', '28pt', '0000cc', 'ffffff'),
(10, '2016-12-12', 'Бетмен', 'Темний лицар: Відродження Легенди ', 'Сюжет: 56-річний Брюс Вейн повертається до боротьби зі злочинністю після 10-річної відставки, проте зустрічається з опозицією в особі поліції Ґотем-сіті і уряду США.', '20pt', '000000', '000000'),
(11, '2016-12-12', 'html ще один код', 'приклад', '&lt;html&gt;&lt;head&gt;&lt;link rel=&quot;stylesheet&quot; href=&quot;redactor_view_blocks.css&quot; type=&quot;text/css&quot;/&gt;&lt;script src=&quot;for_add_theme_btn.js&quot; language=&quot;javascript&quot;&gt;&lt;/script&gt;&lt;/head&gt;&lt;body class = &quot;bodystyle&quot;&gt;&lt;div class = &quot;header_div&quot; id = &quot;redactheaderdiv&quot;&gt;&lt;p&gt;Сайт зі статтями&lt;/p&gt;&lt;/div&gt;&lt;div class = &quot;center_left_div&quot; id = &quot;redactcenterleftdiv&quot;&gt;&lt;p&gt;center_left&lt;/p&gt;&lt;div class = &quot;article_div&quot; style = &quot;align:center;&quot; id = &quot;articlediv&quot;&gt;&lt;/div&gt;&lt;/div&gt;&lt;div class = &quot;left_div&quot; id = &quot;redactleftdiv&quot;&gt; &lt;p&gt;left&lt;/p&gt;&lt;/div&gt;&lt;div class = &quot;footer_div&quot; id = &quot;redactfooterdiv&quot;&gt;&lt;form action=&quot;javascript:func_add_theme_btn()&quot; method=&quot;post&quot;&gt;&lt;input type=&quot;submit&quot; name=&quot;add_theme_btn&quot; value=&quot;Додати тему&quot;/&gt;&lt;/form&gt;&lt;/div&gt;&lt;/body&gt;&lt;/html&gt;', '20pt', '000000', '000000');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `particles`
--
ALTER TABLE `particles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `particles`
--
ALTER TABLE `particles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
